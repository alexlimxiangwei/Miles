package com.neurosky.mindwavemobiledemo;

import java.util.UUID;

public interface Constants {
    public static final String BT_DEVICE = "RNBT-E341";
    public static final UUID BT_UUID = UUID.fromString(
            "00001101-0000-1000-8000-00805F9B34FB");

            //"41eb5f39-6c3a-4067-8bb9-bad64e6e0908");

    public static final String STATE_TEMP = "STATE_TEMP";

    public static final int MESSAGE_BT = 0;
    public static final int MESSAGE_TEMP = 2;
    public static final int MESSAGE_LIGHT = 3;
}