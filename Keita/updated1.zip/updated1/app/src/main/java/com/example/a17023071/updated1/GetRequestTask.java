package com.example.a17023071.updated1;

import android.os.AsyncTask;
import android.util.Log;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class GetRequestTask extends AsyncTask<String, Void, String> {

    private Listener listener;
    private String urlSt;

    // Asynchronous processing
    @Override
    protected String doInBackground(String... params) {

        HttpURLConnection httpConn = null;
        String result = null;
        String word = "word="+params[0];

        try {
            // URL
            URL url = new URL(urlSt);

            // HttpURLConnection
            httpConn = (HttpURLConnection) url.openConnection();

            // request POST
            httpConn.setRequestMethod("POST");

            // no Redirects
            httpConn.setInstanceFollowRedirects(false);

            // writing data
            httpConn.setDoOutput(true);

            // limit
            httpConn.setReadTimeout(10000);
            httpConn.setConnectTimeout(20000);

            // connection
            httpConn.connect();

            // submit POST data
            OutputStream outStream = null;

            try {
                outStream = httpConn.getOutputStream();
                outStream.write( word.getBytes("UTF-8"));
                outStream.flush();
                Log.d("debug","flush");
            } catch (IOException e) {
                // POST error
                e.printStackTrace();
                result="POST error";
            } finally {
                if (outStream != null) {
                    outStream.close();
                }
            }

            final int status = httpConn.getResponseCode();
            if (status == HttpURLConnection.HTTP_OK) {
                // about get response
                result="HTTP_OK";
            }
            else{
                result="status="+String.valueOf(status);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (httpConn != null) {
                httpConn.disconnect();
            }
        }
        return result;
    }

    // after finish of processing
    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);

        if (listener != null) {
            listener.onSuccess(result);
        }
    }

    void getURL(String st)
    {
        urlSt = st;
    }
    void setListener(Listener listener) {
        this.listener = listener;
    }

    interface Listener {
        void onSuccess(String result);
    }
}