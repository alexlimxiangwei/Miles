package com.example.a17033965.ifttt;

import android.os.AsyncTask;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class httpsRequestPost extends AsyncTask<String, Void, Boolean> {
    private String urlo = "https://maker.ifttt.com/trigger/MILES_IFTTT/with/key/cmHIHU7qljF2N9B6z7WSae";
    private Listener listener;
    @Override
    protected Boolean doInBackground(String... strings) {
        boolean state = false;
        HttpsURLConnection urlConnection = null;
        try{
            URL url = new URL(urlo);
            urlConnection = (HttpsURLConnection)url.openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            urlConnection.setDoInput(true);
            urlConnection.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
            urlConnection.setReadTimeout(2000);
            urlConnection.setConnectTimeout(2000);
            urlConnection.connect();
            int responseCode = urlConnection.getResponseCode();
            if( responseCode == HttpsURLConnection.HTTP_OK){
                state = true;
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(urlConnection != null){
                urlConnection.disconnect();
            }
        }
        return state;
    }

    protected void onPostExecute(Boolean result) {
        super.onPostExecute(result);
        if (listener != null) {
            listener.onSuccess(result);
        }

    }
    public void setUrlo(String urlo){
        this.urlo = urlo;
    }
    void setListener(Listener listener) {
        this.listener = listener;
    }

    interface Listener {
        void onSuccess(Boolean result);
    }
}
