package com.example.a17033965.ifttt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button on, off;
    private httpsRequestPost https = new httpsRequestPost();
    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }
    private void off1(){
        https.setUrlo("https://maker.ifttt.com/trigger/IFTTT_KASA_OFF/with/key/cmHIHU7qljF2N9B6z7WSae");
        https.execute();
    }
    private void on1(){
        https.setUrlo("https://maker.ifttt.com/trigger/IFTTT_KASA_ON/with/key/cmHIHU7qljF2N9B6z7WSae");
        https.execute();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Example of a call to a native method
        on = (Button) findViewById(R.id.on);
        off = (Button) findViewById(R.id.off);

        on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                on1();

            }
        });
        off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                off1();

            }
        });
    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
}
