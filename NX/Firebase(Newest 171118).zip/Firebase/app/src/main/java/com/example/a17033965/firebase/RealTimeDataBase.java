package com.example.a17033965.firebase;




public class RealTimeDataBase {
    public String calendar;
    public String input;

    public RealTimeDataBase(){

    }
    public RealTimeDataBase(String calendar, String input) {
        this.calendar = calendar;

        this.input = input;
    }

    public String getCalendar() {
        return calendar;
    }

    public String getInput() {
        return input;
    }

    public void setCalendar(String calendar) {
        this.calendar = calendar;
    }

    public void setInput(String input) {
        this.input = input;
    }
}
