package com.example.a17033965.firebase;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.widget.Button;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;

public class MainView extends AppCompatActivity{
    protected Button back;
    protected ListView list;
    protected ArrayList<RealTimeDataBase> datalist;
    protected DatabaseReference realtimeDatabase;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_main);
        back = findViewById(R.id.back);
        list = findViewById(R.id.list);
        datalist = new ArrayList<>();
        realtimeDatabase =FirebaseDatabase.getInstance().getReference();
        onStart();

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });



    }
    @Override
    protected void onStart() {
        super.onStart();
        realtimeDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                datalist.clear();
                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                    RealTimeDataBase data = dataSnapshot1.getValue(RealTimeDataBase.class);
                    datalist.add(data);
                }
                ShowData adapter = new ShowData(MainView.this, datalist);
                list.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}
