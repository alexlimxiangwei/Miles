package com.example.a17033965.firebase;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class ShowData extends ArrayAdapter<RealTimeDataBase> {
    private Activity context;
    private List<RealTimeDataBase> dataList;
    public ShowData(Activity context, List<RealTimeDataBase> dataList) {
        super(context, R.layout.showdata, dataList);
        this.context = context;
        this.dataList = dataList;

    }

    @NonNull
    @Override
    public View getView(int position, View convertView,  ViewGroup parent) {
        LayoutInflater inflater =context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.showdata,null, true);
        TextView time = (TextView) listViewItem.findViewById(R.id.time);
        TextView input = (TextView) listViewItem.findViewById(R.id.input);

        RealTimeDataBase data = dataList.get(position);
        time.setText(data.getCalendar());
        input.setText(data.getInput());
        return listViewItem;
    }
}
