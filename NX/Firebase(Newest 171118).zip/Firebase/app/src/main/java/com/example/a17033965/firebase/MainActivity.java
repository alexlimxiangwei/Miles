package com.example.a17033965.firebase;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.DateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    protected TextView input;
    protected Button send, view;
    protected DatabaseReference realtimeDatabase;
    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Example of a call to a native method
        input = findViewById(R.id.input);
        send = findViewById(R.id.send);
        view = findViewById(R.id.view);
        realtimeDatabase =FirebaseDatabase.getInstance().getReference();
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                send();
            }
        });
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainView.class);
                startActivity(intent);
            }
        });

    }
    private void send(){
        String now = DateFormat.getDateTimeInstance().format(new Date()).toString();
        String data = input.getText().toString().trim();

        if(!data.isEmpty()){
            String id = realtimeDatabase.push().getKey(); //Collection name
            RealTimeDataBase input = new RealTimeDataBase(now, data);
            realtimeDatabase.child(id).setValue(input);
            Toast.makeText(this, "Data Added", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "Data Not Added", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
}
