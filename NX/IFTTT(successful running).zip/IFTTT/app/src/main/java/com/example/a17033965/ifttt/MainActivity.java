package com.example.a17033965.ifttt;




import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;



public class MainActivity extends AppCompatActivity {
    private httpsRequestPost https = null;
    private String urloff1 = "https://maker.ifttt.com/trigger/Nee_OFF/with/key/cmHIHU7qljF2N9B6z7WSae",
    urlon1 = "https://maker.ifttt.com/trigger/Nee_ON/with/key/cmHIHU7qljF2N9B6z7WSae";
    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    private void off1(){
        //httpsRequestPost need to be reset once, the activity has been restarted.
        httpsRequestPost https = new httpsRequestPost();
        https.setUrlo(urloff1);
        https.execute();
    }
    private void on1(){
        //httpsRequestPost need to be reset once, the activity has been restarted.
        httpsRequestPost https = new httpsRequestPost();
        https.setUrlo(urlon1);
        https.execute();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Example of a call to a native method
        Button on = (Button) findViewById(R.id.on);
        Button off = (Button) findViewById(R.id.off);

        on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                on1();

            }
        });
        off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                off1();
            }
        });
    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
}

