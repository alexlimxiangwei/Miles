package com.example.a17033965.countdownexample;

import android.content.DialogInterface;
import android.os.CountDownTimer;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;

import static java.lang.Long.compare;

public class MainActivity extends AppCompatActivity {
    private static final long START_TIME_IN_MILLIS = 1800000;
    private httpsRequestPost https = null;
    private TextView mTextViewCountDown;
    private Button mButtonStartPause;
    private Button mButtonReset;
//    private boolean reset;
//    private long timeForWarming = 1790000;
    private CountDownTimer mCountDownTimer;
    private String urloff1 = "https://maker.ifttt.com/trigger/Nee_OFF/with/key/cmHIHU7qljF2N9B6z7WSae",
            urlon1 = "https://maker.ifttt.com/trigger/Nee_ON/with/key/cmHIHU7qljF2N9B6z7WSae";
    private boolean mTimerRunning;

    private long mTimeLeftInMillis = START_TIME_IN_MILLIS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextViewCountDown = findViewById(R.id.text_view_countdown);

        mButtonStartPause = findViewById(R.id.button_start_pause);
        mButtonReset = findViewById(R.id.button_reset);
        mButtonReset.setVisibility(View.VISIBLE);
        mButtonStartPause.setVisibility(View.VISIBLE);

        mButtonStartPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mTimerRunning) {
                    pauseTimer();
                } else {
                    startTimer();
                }


            //    startTimer();
            }
        });

        mButtonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetTimer();
            }
        });


        updateCountDownText();
    }

    private void startTimer() {
        onifttt();
        mCountDownTimer = new CountDownTimer(mTimeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimeLeftInMillis = millisUntilFinished;
                updateCountDownText();
                if(mTimeLeftInMillis > 599900 && mTimeLeftInMillis < 600000 ){
                    mTimeLeftInMillis -= 200;
                    pauseTimer();
                    alertMessage();
                }
            }

            @Override
            public void onFinish() {
                mTimerRunning = false;
                mButtonStartPause.setText("Start");
                offifttt();
                /*
                mButtonStartPause.setVisibility(View.INVISIBLE);
                mButtonReset.setVisibility(View.VISIBLE);
                */
            }
        }.start();

        mTimerRunning = true;

        mButtonStartPause.setText("pause");
        /*
        mButtonReset.setVisibility(View.INVISIBLE);
        */


    }

    private void pauseTimer() {
        mCountDownTimer.cancel();
        mTimerRunning = false;
        mButtonStartPause.setText("Start");
        /*
        if(mTimeLeftInMillis < 1740000){
            mButtonReset.setVisibility(View.VISIBLE);
        }
        */

    }

    private void resetTimer() {
        mCountDownTimer.cancel();
        mTimerRunning = false;
        mTimeLeftInMillis = START_TIME_IN_MILLIS;
        startTimer();
        updateCountDownText();
        //mButtonReset.setVisibility(View.INVISIBLE);
        //mButtonStartPause.setVisibility(View.VISIBLE);
    }

    private void updateCountDownText() {
        int minutes = (int) (mTimeLeftInMillis / 1000) / 60;
        int seconds = (int) (mTimeLeftInMillis / 1000) % 60;

        String timeLeftFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);

        mTextViewCountDown.setText(timeLeftFormatted);

    }

    private void alertMessage(){

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setCancelable(true);
        builder.setTitle("Diffuser's water is running dry!!!");
        builder.setMessage("Do you want to continue study?");
        startTimer();
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                dialog.dismiss();
            }
        });

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                resetTimer();
                dialog.dismiss();
            }
        });
        builder.show();

    }
    protected void offifttt(){
        //httpsRequestPost need to be reset once, the activity has been restarted.
        https = new httpsRequestPost();
        https.setUrlo(urloff1);
        https.execute();

    }
    protected void onifttt(){
        //httpsRequestPost need to be reset once, the activity has been restarted.
        https = new httpsRequestPost();
        https.setUrlo(urlon1);
        https.execute();

    }

}
