package com.example.mong0db;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;


public class MainActivity extends AppCompatActivity implements LocationListener {
    Button fetch, save, reset;
    TextView attPoint, medPoint, status;
    private static final String TAG = " MainActivity ";
    protected LocationManager locationManager;
    String msg = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fetch = (Button) findViewById(R.id.fetch);
        save = (Button) findViewById(R.id.save);
        reset = (Button) findViewById(R.id.reset);
        attPoint = findViewById(R.id.attPoint);
        medPoint = findViewById(R.id.medPoint);
        status = findViewById(R.id.status);

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attPoint.setText("");
                medPoint.setText("");
                status.setText("");
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                ValuePoint valuePoint = new ValuePoint();
                String att = attPoint.getText().toString();
                String med = medPoint.getText().toString();
                String date = String.valueOf(LocalDateTime.now());
                String status = "Study";
                while (locationAddress() == null){
                    updateView(locationAddress());
                }
                String location = updateView(locationAddress());
                ValuePoint vp = new ValuePoint(med, att, date, status, location);
                MongoLabInsertContact tsk = new MongoLabInsertContact();
                tsk.execute(vp);
                Log.d("Information: ", valuePoint.toString());

                Toast.makeText(MainActivity.this, "Saved to MongoDB!!", Toast.LENGTH_SHORT).show();
            }
        });

        fetch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<ValuePoint> returnValues = new ArrayList<>();
                GetContactsAsyncTask task = new GetContactsAsyncTask();
                try {
                    returnValues = task.execute().get();
                    if(returnValues.size() > 0){
                        ValuePoint FetchedData = (ValuePoint) returnValues.toArray()[0];
                        attPoint.setText(FetchedData.getAttPoint());
                        medPoint.setText(FetchedData.getMedPoint());
                        status.setText(FetchedData.getDateTime());

                        Toast.makeText(MainActivity.this, "Fetched from MongoDB!!", Toast.LENGTH_SHORT).show();
                    }else{
                        attPoint.setText("");
                        medPoint.setText("");
                        status.setText("");
                        Toast.makeText(MainActivity.this, "No Fetched from MongoDB!!", Toast.LENGTH_SHORT).show();
                    }



                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    final class MongoLabUpdateContact extends AsyncTask<Object, Void, Boolean> {
        @Override
        protected Boolean doInBackground(Object... params) {
            ValuePoint vp = (ValuePoint) params[0];

            try {
                SupportData sd = new SupportData();
                URL url = new URL(sd.buildContactsSaveURL());

                HttpURLConnection connection = (HttpURLConnection) url
                        .openConnection();
                connection.setRequestMethod("PUT");
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type",
                        "application/json");
                connection.setRequestProperty("Accept", "application/json");

                OutputStreamWriter osw = new OutputStreamWriter(
                        connection.getOutputStream());

                osw.write(sd.createValuePoint(vp));
                osw.flush();
                osw.close();

                if(connection.getResponseCode() <205)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            } catch (Exception e) {
                e.getMessage();
                Log.d("Got error", e.getMessage());
                return false;
            }
        }
    }
    final class MongoLabInsertContact extends AsyncTask<Object, Void, Boolean> {
        @Override
        protected Boolean doInBackground(Object... params) {
            ValuePoint vp = (ValuePoint) params[0];

            try {
                SupportData sd = new SupportData();
                URL url = new URL(sd.buildContactsSaveURL());

                HttpURLConnection connection = (HttpURLConnection) url
                        .openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type",
                        "application/json");
                connection.setRequestProperty("Accept", "application/json");

                OutputStreamWriter osw = new OutputStreamWriter(
                        connection.getOutputStream());

                osw.write(sd.createValuePoint(vp));
                osw.flush();
                osw.close();

                if(connection.getResponseCode() <205)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            } catch (Exception e) {
                e.getMessage();
                Log.d("Got error", e.getMessage());
                return false;
            }
        }
    }
    final class GetContactsAsyncTask extends AsyncTask<ValuePoint, Void, ArrayList<ValuePoint>> {
         String server_output = null;
         String temp_output = null;
         ArrayList<ValuePoint> vp = new ArrayList<>();

        @Override
        protected ArrayList<ValuePoint> doInBackground(ValuePoint... arg0) {
            //Log.d("contact22", "Doing");

            try {

                SupportData sd = new SupportData();
                URL url = new URL(sd.buildContactsFetchURL());
                HttpURLConnection conn = (HttpURLConnection) url
                        .openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");
                //Log.d("contact22", "Doing"+conn.toString());

                if (conn.getResponseCode() != 200) {
                    Log.d("contact22", " Response Code: "+String.valueOf(conn.getResponseCode()));
                    throw new RuntimeException("Failed : HTTP error code : "
                            + conn.getResponseCode());

                }
                /*else{
                    Log.e("contact22 Error: ", "Bug" + "No connection");
                }
                */

                BufferedReader br = new BufferedReader(new InputStreamReader(
                        (conn.getInputStream())));
                //Log.d("contact22", " Response Code: "+conn.getInputStream().toString());
                while ((temp_output = br.readLine()) != null) {
                    server_output = temp_output;
                }
                //Log.d("contact22", " Response Code: "+server_output);
                String mongoarray = "{ DB_output: " + server_output + "}";
                //Log.d("contact22", " MongoDB Array "+mongoarray);
                //Object o = new JSONObject(mongoarray);
                Object o =  BasicDBObject.parse(mongoarray);

                //Object o = com.mongodb.util.JSON.parse(mongoarray);
                //Object o = JSON.parse(mongoarray);

                DBObject dbObj = (DBObject) o;

                BasicDBList value = (BasicDBList) dbObj.get("DB_output");
                Log.d("contact20", value.toString());

                for (Object obj : value) {
                    Log.d("contact21", " DBObject "+obj.toString());
                    DBObject userObj = (DBObject) obj;
                    Log.d("contact22", " DBObject "+userObj.toString());
                    ValuePoint temp = new ValuePoint();
                    //Log.d("contact23", " DBObject "+userObj.get("attPoint").toString());

                    temp.setAttPoint(userObj.get("attPoint").toString());
                    temp.setMedPoint(userObj.get("medPoint").toString());
                    temp.setDateTime(userObj.get("status").toString());
                    temp.setDateTime(userObj.get("dateTime").toString());
                    Log.d("contact24", temp.toString());
                    vp.add(temp);

                    Log.d("ID Search ", userObj.get("_id").toString());
                    Log.d("ID Search ",vp.toString());
                }
                Log.d(" TAG GET", vp.toString());

            } catch (Exception e) {
                e.getMessage();
                Log.e("Error: ", "Bug" + e.toString());
            }
            //Log.d("contact22", "mycontacts" + mycontacts.size()+ "Value: " + mycontacts.get(0).first_name);
            return vp;

        }
    }
    //Search is to set the if after getting the data
    final class SearchContactsAsyncTask extends AsyncTask<MyContact, Void, ArrayList<MyContact> > {
        String server_output = null;
        String temp_output = null;
        ArrayList<MyContact> mycontacts = new ArrayList<>();

        @Override
        protected ArrayList<MyContact> doInBackground(MyContact... arg0) {
            //Log.d("contact22", "Doing");

            try {

                SupportData sd = new SupportData();
                URL url = new URL(sd.buildContactsFetchURL());
                HttpURLConnection conn = (HttpURLConnection) url
                        .openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");
                //Log.d("contact22", "Doing"+conn.toString());

                if (conn.getResponseCode() != 200) {
                    Log.d("contact22", " Response Code: "+String.valueOf(conn.getResponseCode()));
                    throw new RuntimeException("Failed : HTTP error code : "
                            + conn.getResponseCode());

                }

                /*else{
                    Log.e("contact22 Error: ", "Bug" + "No connection");
                }
                */

                BufferedReader br = new BufferedReader(new InputStreamReader(
                        (conn.getInputStream())));
                //Log.d("contact22", " Response Code: "+conn.getInputStream().toString());
                while ((temp_output = br.readLine()) != null) {
                    server_output = temp_output;
                }
                //Log.d("contact22", " Response Code: "+server_output);
                String mongoarray = "{ DB_output: " + server_output + "}";
                //Log.d("contact22", " MongoDB Array "+mongoarray);
                //Object o = new JSONObject(mongoarray);
                Object o =  BasicDBObject.parse(mongoarray);

                //Object o = com.mongodb.util.JSON.parse(mongoarray);
                //Object o = JSON.parse(mongoarray);

                DBObject dbObj = (DBObject) o;

                BasicDBList contacts = (BasicDBList) dbObj.get("DB_output");

                for (Object obj : contacts) {
                    DBObject userObj = (DBObject) obj;
                    Log.d("contact22", " DBObject "+userObj.toString());
                    MyContact temp = new MyContact();
                    temp.setFirst_name(userObj.get("first_name").toString());
                    temp.setLast_name(userObj.get("last_name").toString());
                    temp.setPhone_number(userObj.get("phone").toString());
                    mycontacts.add(temp);

                }

            } catch (Exception e) {
                e.getMessage();
                Log.e("Error: ", "Bug" + e.toString());
            }
            Log.d("contact22", "mycontacts" + mycontacts.size()+ "Value: " + mycontacts.get(0).first_name);
            return mycontacts;

        }
    }

    public Location locationAddress(){
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if(!wifiManager.isWifiEnabled()){
            wifiManager.setWifiEnabled(true);
            Log.d(" TAG ", "WiFi is on");
        }

        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            Toast.makeText(MainActivity.this, "On the Network or GPS function", Toast.LENGTH_LONG).show();
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivityForResult(intent, 0);
            //return;
        }
        Location location;
        location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

        if (location == null) {
            locationManager.requestLocationUpdates(getProviderName(), 0, 0, MainActivity.this);

            Log.d(" TAG ", "Nothing happened");
            location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

        }
        Log.d(" TAG ", "OnCreate.location= " + location);
        //reallocation.setText((CharSequence) location);
        updateView(location);

        return location;
    }

    public String updateView (Location location){
        Geocoder gc = new Geocoder(this);
        List<Address> addresses = null;

        if(location !=null){
            try{
                msg = "";
                addresses = gc.getFromLocation(location.getLatitude(), location.getLongitude(),1);

                if(addresses.size() > 0 ){
                    //msg += ";            Country Name: " + addresses.get(0).getCountryName();
                    //msg += ";            Admin Area: "+ addresses.get(0).getAdminArea();
                    //msg += ";            Local: " + addresses.get(0).getLocality();
                    msg = addresses.get(0).getAddressLine(0);
                    //msg += " " + addresses.get(0).getLocality().substring(0,2);

                    return msg;

                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;


    }


    private String getProviderName() {
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        Criteria criteria = new Criteria();
        criteria.setPowerRequirement(Criteria.POWER_LOW); // Chose your desired power consumption level.
        criteria.setAccuracy(Criteria.ACCURACY_FINE); // Choose your accuracy requirement.
        criteria.setSpeedRequired(true); // Chose if speed for first location fix is required.
        criteria.setAltitudeRequired(false); // Choose if you use altitude.
        criteria.setBearingRequired(false); // Choose if you use bearing.
        criteria.setCostAllowed(false); // Choose if this provider can waste money :-)

        // Provide your criteria and flag enabledOnly that tells
        // LocationManager only to return active providers.
        return locationManager.getBestProvider(criteria, true);
    }

    @Override
    public void onLocationChanged(Location location) {
        Log.d(TAG, "onProviderDisabled.location = " + location);
        updateView(location);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        Log.d(TAG, "onStatusChanged() called with " + "provider = [" + provider + "], status = [" + status + "], extras = [" + extras + "]");
        switch (status) {
            case LocationProvider.AVAILABLE:
                Log.i(TAG, "AVAILABLE");
                break;
            case LocationProvider.OUT_OF_SERVICE:
                Log.i(TAG, "OUT_OF_SERVICE");
                break;
            case LocationProvider.TEMPORARILY_UNAVAILABLE:
                Log.i(TAG, "TEMPORARILY_UNAVAILABLE");
                break;
        }


    }

    @Override
    public void onProviderEnabled(String provider) {

        Log.d(TAG, "onProviderEnabled() called with " + "provider = [" + provider + "]");
        try {
            Location location = locationManager.getLastKnownLocation(provider);
            Log.d(TAG, "onProviderDisabled.location = " + location);
            updateView(location);
        }catch (SecurityException e){

        }

    }

    @Override
    public void onProviderDisabled(String provider) {
        Log.d(TAG, "onProviderDisabled() called with " + "provider = [" + provider + "]");
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }










    /*
     final class MongoLabInsertContact extends AsyncTask<Object, Void, Boolean> {
        @Override
        protected Boolean doInBackground(Object... params) {
            MyContact contact = (MyContact) params[0];
            Log.d("contact22", ""+contact);

            try {
                SupportData sd = new SupportData();
                URL url = new URL(sd.buildContactsSaveURL());

                HttpURLConnection connection = (HttpURLConnection) url
                        .openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type",
                        "application/json");
                connection.setRequestProperty("Accept", "application/json");

                OutputStreamWriter osw = new OutputStreamWriter(
                        connection.getOutputStream());

                osw.write(sd.createContact(contact));
                osw.flush();
                osw.close();

                if(connection.getResponseCode() <205)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            } catch (Exception e) {
                e.getMessage();
                Log.d("Got error", e.getMessage());
                return false;
            }
        }
    }
     */
}
