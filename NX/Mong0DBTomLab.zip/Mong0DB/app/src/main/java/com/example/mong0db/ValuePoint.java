package com.example.mong0db;


import android.text.format.Time;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ValuePoint {
    public String medPoint;
    public String attPoint;
    public String dateTime;
    public String status;
    public SimpleDateFormat format= new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZZZZZ", Locale.getDefault());

    public String getMedPoint() {
        return medPoint;
    }

    public void setMedPoint(String medPoint) {
        this.medPoint = medPoint;
    }

    public String getAttPoint() {
        return attPoint;
    }

    public void setAttPoint(String attPoint) {
        this.attPoint = attPoint;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {

        this.dateTime =format.format(new Date());
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


}
