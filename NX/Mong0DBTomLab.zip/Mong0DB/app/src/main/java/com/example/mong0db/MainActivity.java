package com.example.mong0db;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;


public class MainActivity extends AppCompatActivity {
    Button fetch, save, reset;
    TextView firstName, lastName, phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fetch = (Button) findViewById(R.id.fetch);
        save = (Button) findViewById(R.id.save);
        reset = (Button) findViewById(R.id.reset);
        firstName = findViewById(R.id.firstName);
        lastName = findViewById(R.id.lastName);
        phone = findViewById(R.id.phoneNumber);

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firstName.setText("");
                lastName.setText("");
                phone.setText("");
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyContact contact = new MyContact();

                contact.setFirst_name(firstName.getText().toString());
                contact.setLast_name(lastName.getText().toString());
                contact.setPhone_number(phone.getText().toString());

                MongoLabInsertContact tsk = new MongoLabInsertContact();
                tsk.execute(contact);
                Log.d("Information: ", contact.toString());

                Toast.makeText(MainActivity.this, "Saved to MongoDB!!", Toast.LENGTH_SHORT).show();
            }
        });

        fetch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<MyContact> returnValues = new ArrayList<>();
                GetContactsAsyncTask task = new GetContactsAsyncTask();
                try {
                    returnValues = task.execute().get();
                    if(returnValues.size() > 0){
                        MyContact FetchedData = (MyContact) returnValues.toArray()[0];
                        firstName.setText(FetchedData.getFirst_name());
                        lastName.setText(FetchedData.getLast_name());
                        phone.setText(FetchedData.getPhone_nubmer());

                        Toast.makeText(MainActivity.this, "Fetched from MongoDB!!", Toast.LENGTH_SHORT).show();
                    }else{
                        firstName.setText("");
                        lastName.setText("");
                        phone.setText("");
                        Toast.makeText(MainActivity.this, "No Fetched from MongoDB!!", Toast.LENGTH_SHORT).show();
                    }



                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    final class MongoLabUpdateContact extends AsyncTask<Object, Void, Boolean> {
        @Override
        protected Boolean doInBackground(Object... params) {
            MyContact contact = (MyContact) params[0];
            Log.d("contact22", ""+contact);

            try {
                SupportData sd = new SupportData();
                URL url = new URL(sd.buildContactsSaveURL());

                HttpURLConnection connection = (HttpURLConnection) url
                        .openConnection();
                connection.setRequestMethod("PUT");
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type",
                        "application/json");
                connection.setRequestProperty("Accept", "application/json");

                OutputStreamWriter osw = new OutputStreamWriter(
                        connection.getOutputStream());

                osw.write(sd.createContact(contact));
                osw.flush();
                osw.close();

                if(connection.getResponseCode() <205)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            } catch (Exception e) {
                e.getMessage();
                Log.d("Got error", e.getMessage());
                return false;
            }
        }
    }
    final class MongoLabInsertContact extends AsyncTask<Object, Void, Boolean> {
        @Override
        protected Boolean doInBackground(Object... params) {
            MyContact contact = (MyContact) params[0];
            Log.d("contact22", ""+contact);

            try {
                SupportData sd = new SupportData();
                URL url = new URL(sd.buildContactsSaveURL());

                HttpURLConnection connection = (HttpURLConnection) url
                        .openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type",
                        "application/json");
                connection.setRequestProperty("Accept", "application/json");

                OutputStreamWriter osw = new OutputStreamWriter(
                        connection.getOutputStream());

                osw.write(sd.createContact(contact));
                osw.flush();
                osw.close();

                if(connection.getResponseCode() <205)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            } catch (Exception e) {
                e.getMessage();
                Log.d("Got error", e.getMessage());
                return false;
            }
        }
    }
    final class GetContactsAsyncTask extends AsyncTask<MyContact, Void, ArrayList<MyContact>> {
         String server_output = null;
         String temp_output = null;
         ArrayList<MyContact> mycontacts = new ArrayList<>();

        @Override
        protected ArrayList<MyContact> doInBackground(MyContact... arg0) {
            //Log.d("contact22", "Doing");

            try {

                SupportData sd = new SupportData();
                URL url = new URL(sd.buildContactsFetchURL());
                HttpURLConnection conn = (HttpURLConnection) url
                        .openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");
                //Log.d("contact22", "Doing"+conn.toString());

                if (conn.getResponseCode() != 200) {
                    Log.d("contact22", " Response Code: "+String.valueOf(conn.getResponseCode()));
                    throw new RuntimeException("Failed : HTTP error code : "
                            + conn.getResponseCode());

                }
                /*else{
                    Log.e("contact22 Error: ", "Bug" + "No connection");
                }
                */

                BufferedReader br = new BufferedReader(new InputStreamReader(
                        (conn.getInputStream())));
                //Log.d("contact22", " Response Code: "+conn.getInputStream().toString());
                while ((temp_output = br.readLine()) != null) {
                    server_output = temp_output;
                }
                //Log.d("contact22", " Response Code: "+server_output);
                String mongoarray = "{ DB_output: " + server_output + "}";
                //Log.d("contact22", " MongoDB Array "+mongoarray);
                //Object o = new JSONObject(mongoarray);
                Object o =  BasicDBObject.parse(mongoarray);

                //Object o = com.mongodb.util.JSON.parse(mongoarray);
                //Object o = JSON.parse(mongoarray);

                DBObject dbObj = (DBObject) o;

                BasicDBList contacts = (BasicDBList) dbObj.get("DB_output");

                for (Object obj : contacts) {
                    DBObject userObj = (DBObject) obj;
                    Log.d("contact22", " DBObject "+userObj.toString());
                    MyContact temp = new MyContact();
                    temp.setFirst_name(userObj.get("first_name").toString());
                    temp.setLast_name(userObj.get("last_name").toString());
                    temp.setPhone_number(userObj.get("phone").toString());
                    mycontacts.add(temp);
                    //Log.d("ID Search ", userObj.get("_id").toString());
                }

            } catch (Exception e) {
                e.getMessage();
                Log.e("Error: ", "Bug" + e.toString());
            }
            //Log.d("contact22", "mycontacts" + mycontacts.size()+ "Value: " + mycontacts.get(0).first_name);
            return mycontacts;

        }
    }
    //Search is to set the if after getting the data
    final class SearchContactsAsyncTask extends AsyncTask<MyContact, Void, ArrayList<MyContact> > {
        String server_output = null;
        String temp_output = null;
        ArrayList<MyContact> mycontacts = new ArrayList<>();

        @Override
        protected ArrayList<MyContact> doInBackground(MyContact... arg0) {
            //Log.d("contact22", "Doing");

            try {

                SupportData sd = new SupportData();
                URL url = new URL(sd.buildContactsFetchURL());
                HttpURLConnection conn = (HttpURLConnection) url
                        .openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");
                //Log.d("contact22", "Doing"+conn.toString());

                if (conn.getResponseCode() != 200) {
                    Log.d("contact22", " Response Code: "+String.valueOf(conn.getResponseCode()));
                    throw new RuntimeException("Failed : HTTP error code : "
                            + conn.getResponseCode());

                }
                /*else{
                    Log.e("contact22 Error: ", "Bug" + "No connection");
                }
                */

                BufferedReader br = new BufferedReader(new InputStreamReader(
                        (conn.getInputStream())));
                //Log.d("contact22", " Response Code: "+conn.getInputStream().toString());
                while ((temp_output = br.readLine()) != null) {
                    server_output = temp_output;
                }
                //Log.d("contact22", " Response Code: "+server_output);
                String mongoarray = "{ DB_output: " + server_output + "}";
                //Log.d("contact22", " MongoDB Array "+mongoarray);
                //Object o = new JSONObject(mongoarray);
                Object o =  BasicDBObject.parse(mongoarray);

                //Object o = com.mongodb.util.JSON.parse(mongoarray);
                //Object o = JSON.parse(mongoarray);

                DBObject dbObj = (DBObject) o;

                BasicDBList contacts = (BasicDBList) dbObj.get("DB_output");

                for (Object obj : contacts) {
                    DBObject userObj = (DBObject) obj;
                    Log.d("contact22", " DBObject "+userObj.toString());
                    MyContact temp = new MyContact();
                    temp.setFirst_name(userObj.get("first_name").toString());
                    temp.setLast_name(userObj.get("last_name").toString());
                    temp.setPhone_number(userObj.get("phone").toString());
                    mycontacts.add(temp);

                }

            } catch (Exception e) {
                e.getMessage();
                Log.e("Error: ", "Bug" + e.toString());
            }
            Log.d("contact22", "mycontacts" + mycontacts.size()+ "Value: " + mycontacts.get(0).first_name);
            return mycontacts;

        }
    }


}
