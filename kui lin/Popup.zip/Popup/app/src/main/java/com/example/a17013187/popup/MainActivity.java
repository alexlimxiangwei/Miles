package com.example.a17013187.popup;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Dialog dialog;
    private TextView tv_title, tv_message;
    private Button btn_continue, btn_rest, btn_popup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_popup = findViewById(R.id.btn_popup);

        btn_popup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowPopup();
            }
        });

    }
    private void ShowPopup(){
        dialog.setContentView(R.layout.popup_negative);
        btn_rest = dialog.findViewById(R.id.btn_rest);
        btn_continue = dialog.findViewById(R.id.btn_continue);
        tv_title = dialog.findViewById(R.id.tv_title);
        tv_message = dialog.findViewById(R.id.tv_message);

        btn_continue.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                dialog.dismiss();
            }
        });

        btn_rest.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                stop();
                dialog.dismiss();
            }
        });

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

    }
}

