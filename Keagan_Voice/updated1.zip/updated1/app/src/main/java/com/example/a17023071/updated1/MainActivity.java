package com.example.a17023071.updated1;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;

import java.util.ArrayList;
import java.util.Locale;

import static android.media.CamcorderProfile.get;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    SpeechRecognizer mSpeechRecogniser;
    Intent mSpeechRecogniserIntent;
    private Button button2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        button2=(Button) findViewById(R.id.button2);
        
        ///manual button
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openStarted();
                
            }
        });
        Switch sw = (Switch) findViewById(R.id.switch1);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    //Toggle is enabled
                    ///microphone
                    editText.setText("");
                    editText.setHint("Listening...");
                    mSpeechRecogniser.startListening(mSpeechRecogniserIntent);
                    EditText editMessage=(EditText)findViewById(R.id.editText);
                    String message=editMessage.getText().toString();
                    if (message.toLowerCase().equals("study")) {
                        mSpeechRecogniser.stopListening();
                        openStarted();
                    }



                } else {
                    mSpeechRecogniser.stopListening();
                    editText.setHint("You will see the input here");
                    EditText editMessage=(EditText)findViewById(R.id.editText);
                    String message=editMessage.getText().toString();
                    if (message.toLowerCase().equals("study")){
                        openStarted();
                    }

                }

            }
        });



        checkPermission();

        editText=findViewById(R.id.editText);

        mSpeechRecogniser=SpeechRecognizer.createSpeechRecognizer(this);

        mSpeechRecogniserIntent=new Intent (RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        mSpeechRecogniserIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);

        mSpeechRecogniserIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault());

        mSpeechRecogniser.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {

            }

            @Override
            public void onBeginningOfSpeech() {

            }

            @Override
            public void onRmsChanged(float rmsdB) {

            }

            @Override
            public void onBufferReceived(byte[] buffer) {

            }

            @Override
            public void onEndOfSpeech() {

            }

            @Override
            public void onError(int error) {

            }

            @Override
            public void onResults(Bundle bundle) {

                ArrayList<String>matches=bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);

                if(matches!=null) {
                    editText.setText(matches.get(0));
                }
            }

            @Override
            public void onPartialResults(Bundle partialResults) {


            }

            @Override
            public void onEvent(int eventType, Bundle params) {

            }
        });

        findViewById(R.id.button).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()){

                    case MotionEvent.ACTION_UP:
                        mSpeechRecogniser.stopListening();
                        editText.setHint("You will see the input here");
                        EditText editMessage=(EditText)findViewById(R.id.editText);
                        String message=editMessage.getText().toString();
                        if (message.toLowerCase().equals("study")) {
                            mSpeechRecogniser.stopListening();
                            openStarted();
                        }
                        break;
                    case MotionEvent.ACTION_DOWN:
                        editText.setText("");
                        editText.setHint("Listening...");
                        mSpeechRecogniser.startListening(mSpeechRecogniserIntent);


                        break;

                }
                return false;
            }
        });

    }

    private void openStarted() {
        Intent intent = new Intent(this,started.class);
        startActivity(intent);
    }

    private void checkPermission(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){

            if(!(ContextCompat
                    .checkSelfPermission(this,Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED))
            {
                Intent intent=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package"+getPackageName()));
                startActivity(intent);
                finish();

            }
        }
    }
}
