package brainwave.c200.c200;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.IBinder;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

public class Notifications extends NotificationListenerService {

    private NotificationManager mNotificationManager;
    private PendingIntent mBlankIntent;

    @Override
    public IBinder onBind(Intent intent) {
        return super.onBind(intent);
    }


    @Override
    public void onNotificationPosted(StatusBarNotification sbn){
       notification();
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn){
    }

    private void notification(){
        this.mNotificationManager.notify(12321, new Notification.Builder(this)
                .setContentTitle("").setContentText("")
                .setSmallIcon(android.R.color.transparent)
                .setPriority(Notification.PRIORITY_DEFAULT)
                .setFullScreenIntent(this.mBlankIntent, true)
                .setAutoCancel(true)
                .build());


        if(getPackageName().equals("com.my.package")){
            mNotificationManager.cancel(12321);
            return;
        }

    }
    }



