package brainwave.c200.c200;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.speech.SpeechRecognizer;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.support.v4.content.ContextCompat;




public class MainMenu extends AppCompatActivity {
    private Button dashboard, start, setting;
    private SpeechRecognizer mSpeechRecognizer;
    private Intent mSpeechRecognizerIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manu);

        ConstraintLayout constraintLayout = findViewById(R.id.menu_layout);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();

        start = (Button) findViewById(R.id.start);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    Thread.sleep(100);

                    // openStarted()
                    openStarted();
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
            }
        });



    }
    //Start Button method Start
    private void openStarted(){
        Intent intent = new Intent(this, started.class);
        startActivity(intent);
    }
    private void checkPermission(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){

            if(!(ContextCompat
                    .checkSelfPermission(this,Manifest.permission.RECORD_AUDIO) ==
                    PackageManager.PERMISSION_GRANTED))
            {
                Intent intent=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package"+getPackageName()));
                startActivity(intent);
                finish();

            }
        }
    }
        //waiting for PC to create a button for the voice recognization 
    //Start Button method end
}
